#ifndef __DIA_H
#define __DIA_H

#include <stdio.h>

void printBin(int, int);

#endif

